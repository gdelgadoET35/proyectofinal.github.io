document.getElementById('personal').addEventListener('click' , function(){
    document.getElementById('item_').style.display = 'block';
});

document.getElementById('exp').addEventListener('click' , function(){
    document.getElementById('item2').style.display = 'block';
});

document.getElementById('for').addEventListener('click' , function(){
    document.getElementById('item3').style.display = 'block';
});
document.getElementById('leng').addEventListener('click' , function(){
    document.getElementById('item4').style.display = 'block', 'none';
});